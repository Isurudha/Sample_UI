//
//  ViewController.swift
//  Isuru_Dhanisha-COBSCCOMP192p-037
//
//  Created by Isuru Dhanisha  on 2021-01-23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnApple: UIButton!
    @IBOutlet weak var btnFacebook: UIButton!
    @IBOutlet weak var btnGoogle: UIButton!
    @IBOutlet weak var btnEmail: UIButton!
    
    @IBOutlet weak var viewFacebook: UIView!
    @IBOutlet weak var viewGoogle: UIView!
    @IBOutlet weak var viewEmail: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }

    func setupUI(){
        for item in [btnApple,btnFacebook,btnGoogle,btnEmail,viewFacebook,viewGoogle,viewEmail] {
            item?.layer.cornerRadius = 4.0
        }
    }

}

